Vtiger.Class("CallCenter_Js", {
    registerCallPopup: function() {
        // Twilio Integration
        if (typeof Twilio !== 'undefined') {
            const twilioClient = new Twilio.Client('YOUR_TWILIO_TOKEN');
            twilioClient.on('incoming', function(call) {
                const callerId = call.parameters.From;
                jQuery.getJSON('index.php?module=CallCenter&action=GetCallerInfo&callerId=' + callerId, function(data) {
                    if (data.success) {
                        app.showModalWindow({
                            title: 'Incoming Call',
                            body: '<p>Caller: ' + data.callerName + '</p><p><a href="' + data.recordUrl + '">View Record</a></p>'
                        });
                    }
                });
            });
        }

        // Asterisk Integration
        jQuery.getJSON('index.php?module=PBXManager&action=GetAsteriskStatus', function(data) {
            if (data.incomingCall) {
                app.showModalWindow({
                    title: 'Incoming Call',
                    body: '<p>Caller: ' + data.callerName + '</p><p><a href="' + data.recordUrl + '">View Record</a></p>'
                });
            }
        });
    }
}, {
    registerEvents: function() {
        this.registerCallPopup();
    }
});

jQuery(document).ready(function() {
    const instance = new CallCenter_Js();
    instance.registerEvents();
});