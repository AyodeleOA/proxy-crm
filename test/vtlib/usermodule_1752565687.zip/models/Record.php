<?php
//require_once 'vtlib/Vtiger/Record.php';

class CallCenter_Record_Model extends Vtiger_Record_Model {
    public function getCallLogDetails() {
        $db = PearDatabase::getInstance();
        $query = "SELECT * FROM vtiger_pbxmanager WHERE callcenterid = ?";
        $result = $db->pquery($query, [$this->getId()]);
        $callLogs = [];
        while ($row = $db->fetch_array($result)) {
            $callLogs[] = $row;
        }
        return $callLogs;
    }
}