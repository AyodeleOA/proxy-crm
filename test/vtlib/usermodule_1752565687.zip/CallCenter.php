<?php
//require_once 'vtlib/Vtiger/Module.php';

//class CallCenter extends Vtiger_CRMEntity {
class CallCenter extends CRMEntity {
    public $db, $log;
    public $table_name = 'vtiger_callcenter';
    public $table_index = 'callcenterid';
    public $customFieldTable = ['vtiger_callcentercf', 'callcenterid'];
    public $tab_name = ['vtiger_crmentity', 'vtiger_callcenter', 'vtiger_callcentercf'];
    public $tab_name_index = [
        'vtiger_crmentity' => 'crmid',
        'vtiger_callcenter' => 'callcenterid',
        'vtiger_callcentercf' => 'callcenterid'
    ];
    public $column_fields = [];
    public $sortby_fields = ['callcentername', 'call_date', 'call_status'];
    public $list_fields = [
        'Call Center Name' => ['callcenter' => 'callcentername'],
        'Call Date' => ['callcenter' => 'call_date'],
        'Call Status' => ['callcenter' => 'call_status'],
        'Assigned To' => ['crmentity' => 'smownerid']
    ];
    public $list_fields_name = [
        'Call Center Name' => 'callcentername',
        'Call Date' => 'call_date',
        'Call Status' => 'call_status',
        'Assigned To' => 'assigned_user_id'
    ];
    public $list_link_field = 'callcentername';
    public $search_fields = [
        'Call Center Name' => ['callcenter' => 'callcentername'],
        'Call Date' => ['callcenter' => 'call_date']
    ];
    public $search_fields_name = [
        'Call Center Name' => 'callcentername',
        'Call Date' => 'call_date'
    ];
    public $mandatory_fields = ['callcentername', 'assigned_user_id'];
    public $default_order_by = 'callcentername';
    public $default_sort_order = 'ASC';
    public $is_custom_module = true;

    public function __construct() {
        $this->log = LoggerManager::getLogger('CallCenter');
        $this->db = PearDatabase::getInstance();
        $this->column_fields = getColumnFields('CallCenter');
    }
}