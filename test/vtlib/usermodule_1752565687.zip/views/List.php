<?php
require_once 'vtlib/Vtiger/View.php';

class CallCenter_List_View extends Vtiger_List_View {
    public function getListViewEntries($pagingModel) {
        $db = PearDatabase::getInstance();
        $moduleName = $this->getModule()->getName();
        $listQuery = $this->getQuery();
        $startIndex = $pagingModel->getStartIndex();
        $pageLimit = $pagingModel->getPageLimit();
        $listQuery .= " LIMIT $startIndex, $pageLimit";
        $result = $db->pquery($listQuery, []);
        $listViewEntries = [];
        while ($row = $db->fetch_array($result)) {
            $recordModel = Vtiger_Record_Model::getInstanceById($row['callcenterid'], $moduleName);
            $listViewEntries[$row['callcenterid']] = $recordModel;
        }
        return $listViewEntries;
    }
}