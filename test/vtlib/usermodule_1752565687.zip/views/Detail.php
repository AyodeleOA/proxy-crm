<?php
//require_once 'vtlib/Vtiger/View.php';

class CallCenter_Detail_View extends Vtiger_Detail_View {
    public function showModuleDetailView(Vtiger_Request $request) {
        $recordId = $request->get('record');
        $moduleName = $request->getModule();
        $recordModel = Vtiger_Record_Model::getInstanceById($recordId, $moduleName);
        $viewer = $this->getViewer($request);
        $viewer->assign('CALL_LOG_DETAILS', $recordModel->getCallLogDetails());
        return parent::showModuleDetailView($request);
    }
}