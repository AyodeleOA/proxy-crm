<?php

class CallCenter_Save_Action extends Vtiger_Save_Action {
    public function process(Vtiger_Request $request) {
        $recordModel = $this->saveRecord($request);
        $response = new Vtiger_Response();
        $response->setResult(['record' => $recordModel->getId()]);
        $response->emit();
    }
}