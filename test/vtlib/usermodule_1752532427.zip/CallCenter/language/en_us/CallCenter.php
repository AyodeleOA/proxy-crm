<?php
$languageStrings = [
    'CallCenter' => 'Call Center',
    'LBL_CALLCENTER_INFORMATION' => 'Call Center Information',
    'Caller Name' => 'Caller Name',
    'Phone Number' => 'Phone Number',
    'Call Type' => 'Call Type',
    'Call Time' => 'Call Time',
    'Call Duration' => 'Call Duration',
    'Status' => 'Status',
    'Notes' => 'Notes',
    'CallLog' => 'Call Log',
    'PBXManager' => 'PBX Manager',
];
